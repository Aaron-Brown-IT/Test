#ifndef INITIALIZE_H
#define INITIALIZE_H
#include <string>
#include <iostream>
using namespace std;
class init{

};
static string question[5][5];
#endif // INITIALIZE_H
