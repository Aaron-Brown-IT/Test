#include "mainwindow.h"
#include <QApplication>

test::test()
{

}
