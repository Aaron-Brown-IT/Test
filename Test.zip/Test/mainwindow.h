#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QApplication>
#include <QRadioButton>
#include <QPushButton>
#include <QMainWindow>
#include <QLabel>
#include <QString>
#include <string>
#include <iostream>
#include <QXmlStreamReader>
#include <QXmlStreamWriter>
#include <QtCore>
#include <QtXml>
#include <QDebug>
#include <QDomNode>
#include <QFile>
#include <QEvent>
#include <QObject>
#include <QDomText>


using namespace std;

extern bool tag;

namespace Ui {
   class MainWindow;
}

class MainWindow : public QMainWindow
{
   Q_OBJECT
public:
   explicit MainWindow(QWidget *parent = nullptr);
private slots:
   void btnnext();
   void resetRbtn();
   void shuffle();
   void begin();
public:
   void readToArray();
private:
   QDir dir;
   QPushButton *start;
   QWidget w;
   QPushButton *button1;
   QPushButton *button2;
   QRadioButton *answer1;
   QRadioButton *answer2;
   QRadioButton *answer3;
   QRadioButton *answer4;
   QLabel *lable;
   int MAX_ITEMS;
   int number;
   int incnum;
public:
   QString question[101][5];


public:
   int getNum(){
       return this->number;
   }
public:
   void setNum(int num){

        this->number = num;
   }

public:
   int getIncNum(){
       return this->incnum;
   }
public:
   void setIncNum(int num){

        this->incnum = num;
   }

public:
   int getMaxItems(){
       return this->MAX_ITEMS;
   }
public:
   void setMaxItems(int num){

        this->MAX_ITEMS = num;
   }
public:
   void setArray(QString s, int i, int j){

        this->question[i][j] = s;
   }
public:
   QString getArray(int i, int j){
       return this->question[i][j];
   }
};


void sample();
void back();
void choose1();
void choose2();
void choose3();
void choose4();

#endif // MAINWINDOW_H
