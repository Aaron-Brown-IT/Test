#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QApplication>
#include <QRadioButton>
#include <QPushButton>
#include <QMainWindow>
#include <QLabel>
#include <QString>
#include <string>
#include <iostream>
#include <QXmlStreamReader>
#include <QXmlStreamWriter>
#include <QtCore>
#include <QtXml>
#include <QDebug>
#include <QDomNode>
#include <QFile>
#include <QEvent>
#include <QObject>
#include <QDomText>


using namespace std;

extern string question[5][5];
extern bool tag;

namespace Ui {
   class MainWindow;
}

class MainWindow : public QMainWindow
{
   Q_OBJECT
public:
   explicit MainWindow(QWidget *parent = nullptr);
private slots:
   void changebtn();
public:
   QPushButton *m_button;
   QWidget w;
   QPushButton *button1;
   QPushButton *button2;
   QRadioButton *answer1;
   QRadioButton *answer2;
   QRadioButton *answer3;
   QRadioButton *answer4;
   QLabel *lable;
};


void start();
void sample();
void back();
void choose1();
void choose2();
void choose3();
void choose4();

#endif // MAINWINDOW_H
