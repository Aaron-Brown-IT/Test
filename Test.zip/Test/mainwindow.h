#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <iostream>
using namespace std;

extern string question[5][5];
extern bool tag;




void start();
void sample();
void next();
void back();
void choose1();
void choose2();
void choose3();
void choose4();

#endif // MAINWINDOW_H
