#ifndef NEWCLASS_H
#define NEWCLASS_H



void sample();


#endif // NEWCLASS_H
