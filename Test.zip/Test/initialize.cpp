#include <string>
#include <iostream>
using namespace std;



 string question[5][5];


};
