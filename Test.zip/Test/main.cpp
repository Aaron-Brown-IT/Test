#include "mainwindow.h"
#include <QApplication>
#include <QRadioButton>
#include <QPushButton>
#include <QMainWindow>
#include <QLabel>
#include <QString>
#include <string>
#include <iostream>
#include <QXmlStreamReader>
#include <QXmlStreamWriter>
#include <QtCore>
#include <QtXml>
#include <QDebug>
#include <QDomNode>
#include <QFile>
using namespace std;


void ListElements(QDomElement root, QString tagname, QString attribute){
    QDomNodeList items = root.elementsByTagName(tagname);
    cout << "Total items = " << items.count() << endl;

    for(int i = 0; i  < items.count(); i++){
        QDomNode itemnode = items.at(i);

        //convert to element
        if(itemnode.isElement()){
            QDomElement itemele = itemnode.toElement();
            cout << itemele.attribute(attribute).toStdString() << endl;

        }
    }
}

void xmlreader(){

    QDomDocument document;

    QFile file("/home/mhatter/Test/MyXML.xml");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        cout << "Failed to open";
    }
    else{
        if(!document.setContent(&file)){
            cout << "Failed to load document";
        }
        file.close();
    }
    //get the root element
    QDomElement root = document.firstChildElement();

    ListElements(root, "Book", "Name");

    cout << "\r\nMore Advanced\r\n";

    //Get teh chapters
    QDomNodeList books = root.elementsByTagName("Book");
    for(int i = 0; i < books.count(); i++){
        QDomNode booknode = books.at(i);
        //convert to an element
        if(booknode.isElement()){
            QDomElement book = booknode.toElement();
            cout << "Chapters in " << book.attribute("Name").toStdString();
            ListElements(book, "Chapter", "Name");
        }
    }

    cout << "Finished\n";

}

int main(int argc, char *argv[])
{

    QApplication app(argc, argv);

    //Write XML
    QDomDocument document;
    //Make the root element
    QDomElement root = document.createElement("Books");
    //Add it to the document
    document.appendChild(root);

    //Add some elements
    for(int i = 0; i < 10; i++){
        QDomElement book = document.createElement("Book");
        book.setAttribute("Name", " My Book " + QString::number(i));
        book.setAttribute("ID", QString::number(i));
        root.appendChild(book);

        for(int j = 0; j < 10; j++){
            QDomElement chapter = document.createElement("Chapter");
            chapter.setAttribute("Name", " My Chapter " + QString::number(j));
            chapter.setAttribute("ID", QString::number(j));
            book.appendChild(chapter);
        }
    }
    QFile file("/home/mhatter/Test/MyXML.xml");

    if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        cout << "Failed to open file";
        return -1;
    }
    else
    {
        QTextStream stream(&file);
        stream << document.toString();
        file.close();
        cout << "Finished\n";

    }



    xmlreader();

    QWidget w;
    w.setFixedSize(1200, 1000);


    QPushButton button1("Next", &w);
    QPushButton button2("Back", &w);
    QRadioButton answer1("", &w);
    QRadioButton *answer2 = new QRadioButton("%s",&w);
    QRadioButton answer3("question[0][2]", &w);
    QRadioButton answer4("", &w);
    QLabel lable("Lable", &w);

    lable.setGeometry(100, 100, 900, 100);
    lable.setWordWrap(true);
    answer1.setGeometry(10, 200,1000,100);
    answer2->setGeometry(10, 300,1000,100);
    answer3.setGeometry(10, 400,1000,100);
    answer4.setGeometry(10, 500,1000,100);

    button1.setGeometry(1090,940,100,50);
    button2.setGeometry(10,940,100,50);


    start();
    sample();
    w.show();

    app.setWindowIcon(QIcon("/home/mhatter/Pictures/Icons/start.png"));
    return app.exec();

}
