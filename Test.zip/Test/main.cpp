#include "mainwindow.h"

static int j = 0;

void ListElements(QDomElement root, QString tagname, QString attribute){
    QDomNodeList items = root.elementsByTagName(tagname);
    cout << " Total items = " << items.count() << endl;

    for(int i = 0; i  < items.count(); i++){
        QDomNode itemnode = items.at(i);

        //convert to element
        if(itemnode.isElement()){
            QDomElement itemele = itemnode.toElement();
            cout << itemele.attribute(attribute).toStdString() << endl;


        }
    }
}

void xmlreader(){

    QDomDocument document;

    QFile file("MyXML.xml");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        cout << "Failed to open";
    }
    else{
        if(!document.setContent(&file)){
            cout << "Failed to load document";
        }
        file.close();
    }
    //get the root element
    QDomElement root = document.firstChildElement();

    ListElements(root, "Question", "Answer");

    cout << "\r\nMore Advanced\r\n";

    //Get the chapters
    QDomNodeList question = root.elementsByTagName("Question");
    for(int i = 0; i < question.count(); i++){
        QDomNode answer = question.at(i);
        //convert to an element
        if(answer.isElement()){
            QDomElement answer_elem = answer.toElement();
            cout << answer_elem.attribute("Name").toStdString();
            ListElements(answer_elem, "Answer", "Name");
        }
    }

    cout << "Finished\n";

}

void xmlwriter(){


    //Write XML
    QDomDocument document;
    QDomElement root = document.createElement("Test");
    //Add it to the document
    document.appendChild(root);

    //Add some elements
    for(int i = 0; i < 10; i++){
        QDomElement question = document.createElement("Question");
        question.setAttribute("Name", "Question " + QString::number(i));
        question.setAttribute("ID", QString::number(i));
        root.appendChild(question);

        for(int j = 0; j < 4; j++){
            QDomElement Answer = document.createElement("Answer");
            QDomText Text = document.createTextNode("Answer");
            Answer.setAttribute("Name", "Answer " + QString::number(j));
            Answer.setAttribute("ID", QString::number(j));
            Text.setNodeValue("Answer" + QString::number(j));
            //Answer.elementsByTagName("Answer").at(j).setNodeValue("Answer" + QString::number(j));

            question.appendChild(Answer);
            Answer.appendChild(Text);
        }
    }


    QFile file("MyXML.xml");

    if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        cout << "Failed to open file";
    }
    else
    {
        QTextStream stream(&file);
        stream << document.toString();
        file.close();
        cout << "Finished\n";

    }

    //Make the root element


}

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {

                w.setFixedSize(1200, 1000);
                button1 = new QPushButton("Next", &w);
                connect(button1, SIGNAL(clicked()),this, SLOT(changebtn()));
                button2 = new QPushButton("Back", &w);
                answer1 = new QRadioButton("a1", &w);
                answer2 = new QRadioButton("a2", &w);
                answer3 = new QRadioButton("a3", &w);
                answer4 = new QRadioButton("a4", &w);
                lable = new QLabel("Lable", &w);
                lable->setGeometry(100, 100, 900, 100);
                lable->setWordWrap(true);
                answer1->setGeometry(10, 200,1000,100);
                answer2->setGeometry(10, 300,1000,100);
                answer3->setGeometry(10, 400,1000,100);
                answer4->setGeometry(10, 500,1000,100);
                button1->setGeometry(1090,940,100,50);
                button2->setGeometry(10,940,100,50);

                w.show();

}


void MainWindow::changebtn(){

    QDomDocument document;

    QFile file("MyXML.xml");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        cout << "Failed to open";
    }
    else{
        if(!document.setContent(&file)){
            cout << "Failed to load document";
        }
        file.close();
    }


    QDomElement root = document.firstChildElement();
    QString attribute = "Name";
    QDomNodeList items = root.elementsByTagName("Answer");
    cout << " Total items = " << items.count() << endl;

    for(int i = 0; i  < 4; i++){
        QDomNode itemnode = items.at(i + j);

        //convert to element
        if(itemnode.isElement()){
            QDomElement itemele = itemnode.toElement();
            //QDomText itemele = itemnode.toText();
            //QString itemele = itemnode.nodeValue();
            //QDomText Text = itemele.nodeType();
            cout << itemele.text().toStdString() << endl; //.attribute(attribute).toStdString() << endl;
            if(i%4 == 0)
            answer1->setText(itemele.text());
            if(i%4 == 1)
            answer2->setText(itemele.text());//.attribute(attribute));
            if(i%4 == 2)
            answer3->setText(itemele.text());
            if(i%4 == 3)
            answer4->setText(itemele.text());

        }
    }
    j+=4;

}


int main(int argc, char *argv[])
{

    QApplication app(argc, argv);


    xmlwriter();

    xmlreader();

    MainWindow w;
    app.setWindowIcon(QIcon(":/icons/start.png"));

    return app.exec();


}
