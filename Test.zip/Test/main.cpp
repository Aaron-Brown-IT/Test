#include "mainwindow.h"
#include <QApplication>
#include <QRadioButton>
#include <QPushButton>
#include <QMainWindow>
#include <QLabel>
#include <QString>
#include <string>
#include <iostream>
#include <QXmlStreamReader>
#include <QXmlStreamWriter>
#include <QtCore>
#include <QtXml>
#include <QDebug>
#include <QDomNode>
#include <QFile>
using namespace std;


void ListElements(QDomElement root, QString tagname, QString attribute){
    QDomNodeList items = root.elementsByTagName(tagname);
    cout << " Total items = " << items.count() << endl;

    for(int i = 0; i  < items.count(); i++){
        QDomNode itemnode = items.at(i);

        //convert to element
        if(itemnode.isElement()){
            QDomElement itemele = itemnode.toElement();
            cout << itemele.attribute(attribute).toStdString() << endl;
            cout << itemele.text().toStdString();

        }
    }
}

void xmlreader(){

    QDomDocument document;

    QFile file("/home/mhatter/Test/MyXML.xml");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        cout << "Failed to open";
    }
    else{
        if(!document.setContent(&file)){
            cout << "Failed to load document";
        }
        file.close();
    }
    //get the root element
    QDomElement root = document.firstChildElement();

    ListElements(root, "Question", "Answer");

    cout << "\r\nMore Advanced\r\n";

    //Get the chapters
    QDomNodeList question = root.elementsByTagName("Question");
    for(int i = 0; i < question.count(); i++){
        QDomNode answer = question.at(i);
        //convert to an element
        if(answer.isElement()){
            QDomElement answer_elem = answer.toElement();
            cout << answer_elem.attribute("Name").toStdString();
            ListElements(answer_elem, "Answer", "Name");
        }
    }

    cout << "Finished\n";

}

void xmlwriter(){

    //Write XML
    QDomDocument document;
    //Make the root element
    QDomElement root = document.createElement("Test");
    //Add it to the document
    document.appendChild(root);

    //Add some elements
    for(int i = 0; i < 10; i++){
        QDomElement question = document.createElement("Question");
        question.setAttribute("Name", "Question " + QString::number(i));
        question.setAttribute("ID", QString::number(i));
        root.appendChild(question);

        for(int j = 0; j < 4; j++){
            QDomElement Answer = document.createElement("Answer");
            Answer.setAttribute("Name", "Answer " + QString::number(j));
            Answer.setAttribute("ID", QString::number(j));
            question.appendChild(Answer);
        }
    }
    QFile file("/home/mhatter/Test/MyXML.xml");

    if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        cout << "Failed to open file";
    }
    else
    {
        QTextStream stream(&file);
        stream << document.toString();
        file.close();
        cout << "Finished\n";

    }

}
class window {
        QWidget w;

public:
    window(){

        w.setFixedSize(1200, 1000);

        setButtons();
        w.show();

    }

    void setButtons(){

        QPushButton *button1 = new QPushButton("Next", &w);
        QPushButton *button2 = new QPushButton("Back", &w);
        QRadioButton *answer1 = new QRadioButton("a1", &w);
        QRadioButton *answer2 = new QRadioButton("a2", &w);
        QRadioButton *answer3 = new QRadioButton("a3", &w);
        QRadioButton *answer4 = new QRadioButton("a4", &w);
        QLabel *lable = new QLabel("Lable", &w);
        lable->setGeometry(100, 100, 900, 100);
        lable->setWordWrap(true);
        answer1->setGeometry(10, 200,1000,100);
        answer2->setGeometry(10, 300,1000,100);
        answer3->setGeometry(10, 400,1000,100);
        answer4->setGeometry(10, 500,1000,100);
        button1->setGeometry(1090,940,100,50);
        button2->setGeometry(10,940,100,50);

    }



};

void init(){




}

int main(int argc, char *argv[])
{

    QApplication app(argc, argv);


    xmlwriter();

    xmlreader();

    window w;

    app.setWindowIcon(QIcon("/home/mhatter/Pictures/Icons/start.png"));

    return app.exec();


}
