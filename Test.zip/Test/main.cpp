#include "mainwindow.h"


void xmlwriter(){

    //Write XML
    QDomDocument document;
    QDomElement root = document.createElement("Test");
    //Add it to the document
    document.appendChild(root);

    //Add some elements
    for(int i = 0; i < 10; i++){
        QDomElement question = document.createElement("Question");
        question.setAttribute("Name", "Question " + QString::number(i));
        question.setAttribute("ID", QString::number(i));
        root.appendChild(question);

        for(int j = 0; j < 4; j++){
            QDomElement Answer = document.createElement("Answer");
            QDomText Text = document.createTextNode("Answer");
            Answer.setAttribute("Name", "Answer " + QString::number(j));
            Answer.setAttribute("ID", QString::number(j));
            Text.setNodeValue(QString::number(i));

            question.appendChild(Answer);
            Answer.appendChild(Text);

        }
    }


    QFile file("/home/mhatter/Test/MyXML.xml");

    if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        cout << "Failed to open file";
    }
    else
    {
        QTextStream stream(&file);
        stream << document.toString();
        file.close();
        cout << "Finished\n";
    }

}

void MainWindow::readToArray(){

    QDomDocument document;

    QFile file("/home/mhatter/Test/MyXML.xml");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        cout << "Failed to open";
    }
    else{
        if(!document.setContent(&file)){
            cout << "Failed to load document";
        }
        file.close();
    }

    QDomElement root = document.firstChildElement();

    QDomNodeList items = root.elementsByTagName("Answer");
    cout << " Total items = " << items.count() << endl;

    for(int i = 0; i  < 10; i++){
        QDomNode itemnode = items.at(getNum());

        //convert to element
        if(itemnode.isElement()){
            QDomElement itemele = itemnode.toElement();


            for(int j = 0; j  < 4; j++){
                cout << itemele.text().toStdString();

            setArray(itemele.text(), i, j);
            }
            setNum(getNum() + 4);
            cout << endl;

        }
    }
}

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {

                w.setFixedSize(1200, 1000);
                start = new QPushButton("Start", &w);
                start->setGeometry(550,940,100,50);
                connect(start, SIGNAL(clicked()),this, SLOT(begin()));

                w.show();

}

void MainWindow::begin(){


    w.close();
    start->close();
    button1 = new QPushButton("Next", &w);
    connect(button1, SIGNAL(clicked()),this, SLOT(btnnext()));
    button2 = new QPushButton("Back", &w);
    connect(button2, SIGNAL(clicked()),this, SLOT(btnback()));
    answer1 = new QRadioButton("a1", &w);
    answer2 = new QRadioButton("a2", &w);
    answer3 = new QRadioButton("a3", &w);
    answer4 = new QRadioButton("a4", &w);
    lable = new QLabel("Lable", &w);
    lable->setGeometry(100, 100, 900, 100);
    lable->setWordWrap(true);
    answer1->setGeometry(10, 200,1000,100);
    answer2->setGeometry(10, 300,1000,100);
    answer3->setGeometry(10, 400,1000,100);
    answer4->setGeometry(10, 500,1000,100);
    button1->setGeometry(1090,940,100,50);
    button2->setGeometry(10,940,100,50);

    answer1->setText(getArray(getIncNum(),0));

    answer2->setText(getArray(getIncNum(),1));

    answer3->setText(getArray(getIncNum(),2));

    answer4->setText(getArray(getIncNum(),3));

    w.show();



}
void MainWindow::btnnext(){

    incNum(getIncNum() + 1);

    answer1->setText(getArray(getIncNum(),0));

    answer2->setText(getArray(getIncNum(),1));

    answer3->setText(getArray(getIncNum(),2));

    answer4->setText(getArray(getIncNum(),3));

}

void MainWindow::btnback(){

    incNum(getIncNum() - 1);

    answer1->setText(getArray(getIncNum(),0));

    answer2->setText(getArray(getIncNum(),1));

    answer3->setText(getArray(getIncNum(),2));

    answer4->setText(getArray(getIncNum(),3));


}


int main(int argc, char *argv[])
{

    QApplication app(argc, argv);
    MainWindow window;
    window.setNum(0);

    xmlwriter();
    window.readToArray();

    window.incNum(0);

    for (int i = 0; i < 10; i++){
        for(int j = 0; j < 4; j++){
            cout << window.getArray(i,j).toStdString();
        }
        cout << endl;
    }

    app.setWindowIcon(QIcon(":/icons/start.png"));

    return app.exec();


}
