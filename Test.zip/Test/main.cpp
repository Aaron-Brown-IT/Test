#include "mainwindow.h"

void xmlwriter(){

    QDomDocument document;
    QDomElement root = document.createElement("Test");

    document.appendChild(root);

    for(int i = 0; i < 10; i++){
        QDomElement question = document.createElement("Question");
        question.setAttribute("Name", "Question " + QString::number(i));
        question.setAttribute("ID", QString::number(i));
        root.appendChild(question);

        for(int j = 0; j < 5; j++){
            QDomElement Answer = document.createElement("Answer");
            QDomText Text = document.createTextNode("Answer");
            Answer.setAttribute("Name", "Answer " + QString::number(j));
            Answer.setAttribute("ID", QString::number(j));
            Text.setNodeValue(QString::number(i));

            question.appendChild(Answer);
            Answer.appendChild(Text);

        }
    }

    QFile file("MyXML.xml");

    if(!file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        cout << "Failed to open file";
    }
    else
    {
        QTextStream stream(&file);
        stream << document.toString();
        file.close();
        cout << "Finished\n";
    }
}

void MainWindow::readToArray(){

    QDomDocument document;

    QFile file("MyXML.xml");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        cout << "Failed to open";
    }
    else{
        if(!document.setContent(&file)){
            cout << "Failed to load document";
        }
        file.close();
    }

    QDomElement root = document.firstChildElement();

    QDomNodeList items = root.elementsByTagName("Answer");
    cout << " Total items = " << items.count() << endl;
    setMaxItems(items.count());

    for(int i = 0; i  < getMaxItems() / 5; i++){

            for(int j = 0; j  < getMaxItems() / (getMaxItems() / 5); j++){
                QDomNode itemnode = items.at(j + getNum());
                QDomElement itemele = itemnode.toElement();


                cout << itemele.text().toStdString();

            setArray(itemele.text(), i, j);
            }
            setNum(getNum() + 5);
            cout << endl;

    }
}

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {

                w.setFixedSize(1200, 1000);
                start = new QPushButton("Start", &w);
                start->setGeometry(550,940,100,50);
                connect(start, SIGNAL(clicked()),this, SLOT(begin()));

                w.show();

}

void MainWindow::begin(){


    w.close();
    start->close();
    button1 = new QPushButton("Next", &w);
    connect(button1, SIGNAL(clicked()),this, SLOT(btnnext()));
    answer1 = new QRadioButton("a1", &w);
    answer2 = new QRadioButton("a2", &w);
    answer3 = new QRadioButton("a3", &w);
    answer4 = new QRadioButton("a4", &w);
    lable = new QLabel("Begin", &w);
    lable->setGeometry(100, 100, 900, 100);
    lable->setWordWrap(true);
    answer1->setGeometry(10, 200,1000,100);
    answer2->setGeometry(10, 300,1000,100);
    answer3->setGeometry(10, 400,1000,100);
    answer4->setGeometry(10, 500,1000,100);
    button1->setGeometry(1090,940,100,50);

    shuffle();

    w.show();



}

void MainWindow::resetRbtn(){

    answer1->setAutoExclusive(false);
    answer1->setChecked(false);
    answer1->setAutoExclusive(true);

    answer2->setAutoExclusive(false);
    answer2->setChecked(false);
    answer2->setAutoExclusive(true);

    answer3->setAutoExclusive(false);
    answer3->setChecked(false);
    answer3->setAutoExclusive(true);

    answer4->setAutoExclusive(false);
    answer4->setChecked(false);
    answer4->setAutoExclusive(true);
}

void MainWindow::shuffle(){
/*
    answer1->setText(getArray(getIncNum(),1));
    answer2->setText(getArray(getIncNum(),2));
    answer3->setText(getArray(getIncNum(),3));
    answer4->setText(getArray(getIncNum(),4));

    */


    int num1 = 2, num2 = 3, num3 = 4, placement = 1;

    srand(static_cast<uint>(time(nullptr)));

    placement = rand() % 4 + 1;

    do {
        num1 = rand() % 4 + 1;
    }while(question[getIncNum()][num1].compare(question[getIncNum()][1]) == 0);

    do {
        num2 = rand() % 4 + 1;
    }while(question[getIncNum()][num2].compare(question[getIncNum()][1]) == 0 || num2 == num1);

    do {
        num3 = rand() % 4 + 1;
    }while(question[getIncNum()][num3].compare(question[getIncNum()][1]) == 0 || num3 == num2 || num3 == num1);


    if (placement == 1){
    answer1->setText(getArray(getIncNum(),1));
    answer2->setText(getArray(getIncNum(),num1));
    answer3->setText(getArray(getIncNum(),num2));
    answer4->setText(getArray(getIncNum(),num3));
    }
    if (placement == 2){
    answer1->setText(getArray(getIncNum(),num1));
    answer2->setText(getArray(getIncNum(),1));
    answer3->setText(getArray(getIncNum(),num2));
    answer4->setText(getArray(getIncNum(),num3));
    }
    if (placement == 3){
    answer1->setText(getArray(getIncNum(),num1));
    answer2->setText(getArray(getIncNum(),num2));
    answer3->setText(getArray(getIncNum(),1));
    answer4->setText(getArray(getIncNum(),num3));
    }
    if (placement == 4){
    answer1->setText(getArray(getIncNum(),num1));
    answer2->setText(getArray(getIncNum(),num2));
    answer3->setText(getArray(getIncNum(),num3));
    answer4->setText(getArray(getIncNum(),1));
    }


}

void MainWindow::btnnext(){

    if(answer1->isChecked() || answer2->isChecked() || answer3->isChecked() || answer4->isChecked()){


        cout << answer2->text().compare(getArray(getIncNum(), 1));

    if(answer1->isChecked() && answer1->text().compare(getArray(getIncNum(), 1)) == 0){
        lable->setText("correct: " + getArray(getIncNum(), 0));
    }
    else if(answer2->isChecked() && answer2->text().compare(getArray(getIncNum(), 1)) == 0){
        lable->setText("correct: " + getArray(getIncNum(), 0));
    }
    else if(answer3->isChecked() && answer3->text().compare(getArray(getIncNum(), 1)) == 0){
        lable->setText("correct: " + getArray(getIncNum(), 0));
    }
    else if(answer4->isChecked() && answer4->text().compare(getArray(getIncNum(), 1)) == 0){
        lable->setText("correct: " + getArray(getIncNum(), 0));
    }
    else{
        lable->setText("incorrect: " + getArray(getIncNum(), 0));
        cout << "incorrect";
    }
    setIncNum(getIncNum() + 1);

    shuffle();

    resetRbtn();

    }
}


int main(int argc, char *argv[])
{

    QApplication app(argc, argv);
    MainWindow window;
    window.setNum(0);

    //xmlwriter();
    window.readToArray();

    window.setIncNum(0);

    for (int i = 0; i < window.getMaxItems() / 5; i++){
        for(int j = 0; j < window.getMaxItems() / (window.getMaxItems() / 5); j++){
            cout << window.getArray(i,j).toStdString();
        }
        cout << endl;
    }

    app.setWindowIcon(QIcon(":/icons/start.png"));

    return app.exec();


}
