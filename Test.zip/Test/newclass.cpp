#include <iostream>
#include "mainwindow.h"
using namespace std;

void sample()
{
    cout << "test1" << question[0][0] << endl;
}


void print(string words){
    cout << words;
}

