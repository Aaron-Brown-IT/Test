#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <string>
#include <iostream>
using namespace std;

string question[5][5];
bool tag;

void start() {

    question[0][0] = "q1";
    question[0][1] = "a1";
    question[0][2] = "a2";
    question[0][3] = "a3";
    question[0][4] = "a4";

    question[1][0] = "q2";
    question[1][1] = "a1";
    question[1][2] = "a2";
    question[1][3] = "a3";
    question[1][4] = "a4";

    question[2][0] = "q3";
    question[2][1] = "a1";
    question[2][2] = "a2";
    question[2][3] = "a3";
    question[2][4] = "a4";

    question[3][0] = "q4";
    question[3][1] = "a1";
    question[3][2] = "a2";
    question[3][3] = "a3";
    question[3][4] = "a4";

    question[4][0] = "q5";
    question[4][1] = "a1";
    question[4][2] = "a2";
    question[4][3] = "a3";
    question[4][4] = "a4";

}





